# 🚀 RPA-PORT Customs AI - DigitalOcean Setup Guide

## Website: www.rpa-port.com
## Contact: devrpa@rpa-port.co.il

---

## 📁 Step 1: Create GitHub Repository

Create a new repository with this structure:

```
your-repo/
├── app/
│   ├── __init__.py       (empty file)
│   └── main.py           (copy from DO_app_main.py)
├── Dockerfile            (copy from DO_Dockerfile.txt, rename to just "Dockerfile")
├── Procfile              (copy from DO_Procfile.txt, rename to just "Procfile")
├── requirements.txt      (copy from DO_requirements.txt)
└── runtime.txt           (contains just: python-3.11.7)
```

---

## 📄 Step 2: File Contents

### File: `requirements.txt`
```
fastapi==0.109.0
uvicorn[standard]==0.27.0
anthropic==0.18.1
python-multipart==0.0.6
pydantic==2.6.0
pydantic-settings==2.1.0
structlog==24.1.0
httpx==0.26.0
python-dotenv==1.0.1
```

### File: `Procfile` (no extension!)
```
web: uvicorn app.main:app --host 0.0.0.0 --port ${PORT:-8000}
```

### File: `runtime.txt`
```
python-3.11.7
```

### File: `Dockerfile`
```dockerfile
FROM python:3.11-slim

ENV PYTHONDONTWRITEBYTECODE=1
ENV PYTHONUNBUFFERED=1
ENV PORT=8000

WORKDIR /app

RUN apt-get update && apt-get install -y curl && rm -rf /var/lib/apt/lists/*

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

EXPOSE 8000

CMD uvicorn app.main:app --host 0.0.0.0 --port ${PORT:-8000}
```

### File: `app/__init__.py`
```python
# RPA-PORT Customs AI
```

### File: `app/main.py`
(Copy the content from DO_app_main.py file)

---

## 🌐 Step 3: DigitalOcean Setup

1. Go to: https://cloud.digitalocean.com/apps
2. Click "Create App"
3. Choose "GitHub"
4. Select your repository
5. DigitalOcean should auto-detect:
   - Type: Web Service
   - Build: Dockerfile
   
---

## 🔑 Step 4: Environment Variables

In DigitalOcean App settings, add:

| Key | Value | Type |
|-----|-------|------|
| `ANTHROPIC_API_KEY` | `sk-ant-api03-xxx...` | Secret |

---

## ✅ Step 5: Deploy

Click "Deploy" and wait for build to complete.

Your API will be available at:
- `https://your-app.ondigitalocean.app/`
- `https://your-app.ondigitalocean.app/docs` (Swagger UI)
- `https://your-app.ondigitalocean.app/health`

---

## 🧪 Test Your API

```bash
# Health check
curl https://your-app.ondigitalocean.app/health

# Chat (Hebrew)
curl -X POST https://your-app.ondigitalocean.app/api/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "איך מסווגים טלפון נייד?"}'

# Classify
curl -X POST https://your-app.ondigitalocean.app/api/classify \
  -H "Content-Type: application/json" \
  -d '{"description": "אוזניות אלחוטיות בלוטוס"}'
```

---

## 💰 Estimated Cost

| Resource | Cost/Month |
|----------|------------|
| Basic App | $5 |
| Claude API | ~$50 (usage based) |
| **Total** | ~$55/month |

---

## 📞 Support

- Website: https://www.rpa-port.com
- Email: devrpa@rpa-port.co.il
