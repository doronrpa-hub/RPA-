"""
RPA-PORT Israeli Customs AI
Main FastAPI Application
Website: www.rpa-port.com
Contact: devrpa@rpa-port.co.il
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
import anthropic
import os

# Create FastAPI app
app = FastAPI(
    title="RPA-PORT Israeli Customs AI",
    description="AI-powered Israeli Customs Classification System",
    version="1.0.0",
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://www.rpa-port.com", "http://localhost:3000", "*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Anthropic client - initialized when needed
def get_client():
    api_key = os.getenv("ANTHROPIC_API_KEY", "")
    if not api_key:
        raise HTTPException(status_code=500, detail="ANTHROPIC_API_KEY not configured")
    return anthropic.Anthropic(api_key=api_key)

# System prompt for Claude
SYSTEM_PROMPT = """אתה מומחה בכיר למכס ישראלי של חברת RPA-PORT LTD, עם ידע מעמיק ב:

📚 מקורות ידע:
- פקודת המכס (נוסח חדש)
- נוהל תש"ר 2024 (תהליך השחרור)
- צו תעריף המכס והפטורים ומס קנייה
- הסכמי סחר בינלאומיים (ארה"ב, האיחוד האירופי, EFTA, ועוד)
- דרישות משרדי ממשלה (בריאות, חקלאות, מכון התקנים)

🎯 יכולות:
- סיווג טובין לפי HS Code (10 ספרות)
- ניתוח הצהרות יבוא ויצוא
- חישוב מיסים (מכס, מע"מ, מס קנייה)
- זיהוי הטבות מהסכמי סחר
- בדיקת דרישות רישוי ותקינה

🗣️ שפה:
- מדבר עברית מקצועית (מונחים רשמיים)
- יכול לענות גם באנגלית
- משתמש במונחים מתעריף המכס הישראלי

📋 כללים:
1. תמיד לציין מקור המידע (סעיף חוק, נוהל)
2. להזהיר כשיש אי-ודאות
3. להפנות לייעוץ מקצועי בנושאים מורכבים

אני כאן לעזור לך בכל שאלה הקשורה ליבוא, יצוא, סיווג ומכס בישראל!"""


# Request/Response Models
class ChatRequest(BaseModel):
    message: str
    history: Optional[List[Dict[str, str]]] = None
    tenant_id: Optional[str] = None

class ChatResponse(BaseModel):
    response: str
    tenant_id: Optional[str] = None

class ClassifyRequest(BaseModel):
    description: str
    additional_info: Optional[Dict[str, Any]] = None

class ClassifyResponse(BaseModel):
    result: str
    hs_code: Optional[str] = None


# Routes
@app.get("/")
async def root():
    """Root endpoint with API information"""
    return {
        "name": "RPA-PORT Israeli Customs AI",
        "version": "1.0.0",
        "website": "https://www.rpa-port.com",
        "contact": "devrpa@rpa-port.co.il",
        "endpoints": {
            "docs": "/docs",
            "health": "/health",
            "chat": "/api/chat",
            "classify": "/api/classify",
        }
    }


@app.get("/health")
async def health():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": "rpa-port-customs-ai",
        "version": "1.0.0",
    }


@app.post("/api/chat", response_model=ChatResponse)
async def chat(request: ChatRequest):
    """
    Chat with the Customs AI
    
    Supports Hebrew and English
    """
    try:
        client = get_client()
        
        # Build messages
        messages = []
        if request.history:
            messages.extend(request.history)
        messages.append({"role": "user", "content": request.message})
        
        # Call Claude
        response = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=4096,
            system=SYSTEM_PROMPT,
            messages=messages,
        )
        
        return ChatResponse(
            response=response.content[0].text,
            tenant_id=request.tenant_id,
        )
        
    except anthropic.APIError as e:
        raise HTTPException(status_code=500, detail=f"Claude API error: {str(e)}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/classify", response_model=ClassifyResponse)
async def classify(request: ClassifyRequest):
    """
    Classify a product and get HS code
    """
    prompt = f"""סווג את המוצר הבא לפי תעריף המכס הישראלי:

**תיאור המוצר:** {request.description}

{f"**מידע נוסף:** {request.additional_info}" if request.additional_info else ""}

אנא החזר:
1. קוד HS מלא (10 ספרות)
2. תיאור בעברית
3. שיעור מכס
4. מס קנייה (אם יש)
5. דרישות מיוחדות (רישיונות, תקנים)
6. רמת ודאות בסיווג"""
    
    try:
        client = get_client()
        
        response = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=2048,
            system=SYSTEM_PROMPT,
            messages=[{"role": "user", "content": prompt}],
        )
        
        return ClassifyResponse(result=response.content[0].text)
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/agreements")
async def list_agreements():
    """List all trade agreements"""
    return {
        "agreements": [
            {"code": "2", "name": "Israel-USA FTA", "year": 1985},
            {"code": "92", "name": "Israel-EU Association", "year": 1995},
            {"code": "EFTA", "name": "Israel-EFTA", "year": 1992},
            {"code": "CA", "name": "Israel-Canada FTA", "year": 1997},
            {"code": "MX", "name": "Israel-Mexico FTA", "year": 2000},
            {"code": "TR", "name": "Israel-Turkey FTA", "year": 1997},
            {"code": "KR", "name": "Israel-South Korea FTA", "year": 2021},
            {"code": "AE", "name": "Israel-UAE FTA", "year": 2022},
            {"code": "UA", "name": "Israel-Ukraine FTA", "year": 2021},
            {"code": "VN", "name": "Israel-Vietnam FTA", "year": 2024},
        ]
    }


# Run with: uvicorn app.main:app --reload
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
