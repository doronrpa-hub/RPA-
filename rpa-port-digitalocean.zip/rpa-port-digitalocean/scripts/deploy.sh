#!/bin/bash
# RPA-PORT Israeli Customs AI
# DigitalOcean Deployment Script

set -e

echo "🚀 RPA-PORT Customs AI - DigitalOcean Deployment"
echo "================================================"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check requirements
check_requirements() {
    echo -e "${YELLOW}Checking requirements...${NC}"
    
    # Check Docker
    if ! command -v docker &> /dev/null; then
        echo -e "${RED}Docker is not installed. Please install Docker first.${NC}"
        exit 1
    fi
    
    # Check docker-compose
    if ! command -v docker-compose &> /dev/null; then
        echo -e "${RED}docker-compose is not installed. Please install docker-compose first.${NC}"
        exit 1
    fi
    
    # Check .env file
    if [ ! -f ".env" ]; then
        echo -e "${YELLOW}Creating .env file from template...${NC}"
        cp .env.example .env
        echo -e "${RED}Please edit .env file with your credentials before running again.${NC}"
        exit 1
    fi
    
    echo -e "${GREEN}All requirements met!${NC}"
}

# Build Docker images
build() {
    echo -e "${YELLOW}Building Docker images...${NC}"
    docker-compose build --no-cache
    echo -e "${GREEN}Build complete!${NC}"
}

# Start services
start() {
    echo -e "${YELLOW}Starting services...${NC}"
    docker-compose up -d
    echo -e "${GREEN}Services started!${NC}"
    
    echo -e "\n${GREEN}Application is running at:${NC}"
    echo "  - API: http://localhost:8000"
    echo "  - Docs: http://localhost:8000/docs"
    echo "  - WebSocket: ws://localhost:8000/ws/chat"
}

# Stop services
stop() {
    echo -e "${YELLOW}Stopping services...${NC}"
    docker-compose down
    echo -e "${GREEN}Services stopped!${NC}"
}

# View logs
logs() {
    docker-compose logs -f app
}

# Run health check
health() {
    echo -e "${YELLOW}Running health check...${NC}"
    
    response=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:8000/health)
    
    if [ "$response" == "200" ]; then
        echo -e "${GREEN}Health check passed! (HTTP $response)${NC}"
        curl -s http://localhost:8000/health | jq .
    else
        echo -e "${RED}Health check failed! (HTTP $response)${NC}"
        exit 1
    fi
}

# Deploy to production
deploy_production() {
    echo -e "${YELLOW}Deploying to production...${NC}"
    
    # Build and push to registry
    docker-compose build
    
    # Tag for registry (update with your registry)
    docker tag rpa-port-customs-ai:latest registry.digitalocean.com/rpa-port/customs-ai:latest
    
    # Push to registry
    docker push registry.digitalocean.com/rpa-port/customs-ai:latest
    
    echo -e "${GREEN}Deployed to production!${NC}"
}

# Backup database
backup() {
    echo -e "${YELLOW}Creating database backup...${NC}"
    
    timestamp=$(date +%Y%m%d_%H%M%S)
    backup_file="backup_${timestamp}.sql"
    
    docker-compose exec db pg_dump -U rpaport customs_ai > "backups/${backup_file}"
    
    echo -e "${GREEN}Backup created: backups/${backup_file}${NC}"
}

# Show usage
usage() {
    echo "Usage: $0 {check|build|start|stop|logs|health|deploy|backup}"
    echo ""
    echo "Commands:"
    echo "  check   - Check requirements"
    echo "  build   - Build Docker images"
    echo "  start   - Start all services"
    echo "  stop    - Stop all services"
    echo "  logs    - View application logs"
    echo "  health  - Run health check"
    echo "  deploy  - Deploy to production"
    echo "  backup  - Backup database"
}

# Main
case "$1" in
    check)
        check_requirements
        ;;
    build)
        check_requirements
        build
        ;;
    start)
        check_requirements
        start
        ;;
    stop)
        stop
        ;;
    logs)
        logs
        ;;
    health)
        health
        ;;
    deploy)
        check_requirements
        deploy_production
        ;;
    backup)
        backup
        ;;
    *)
        usage
        exit 1
        ;;
esac
