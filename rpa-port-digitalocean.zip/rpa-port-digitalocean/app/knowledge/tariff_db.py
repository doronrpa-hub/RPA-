"""
RPA-PORT Israeli Customs AI
Tariff Database - Knowledge Base Manager
"""

import json
import os
from typing import Optional, List, Dict, Any
from datetime import datetime
import structlog
from pathlib import Path

logger = structlog.get_logger()


class TariffDatabase:
    """
    Manages the Israeli Customs Tariff knowledge base
    
    Loads and provides access to:
    - HS codes and descriptions
    - Duty rates
    - Trade agreements
    - Procedures (TASHAR)
    - Hebrew terminology
    """
    
    def __init__(self, knowledge_path: str = "knowledge_base"):
        self.knowledge_path = Path(knowledge_path)
        self.data: Dict[str, Any] = {}
        self.last_updated: Optional[datetime] = None
        self.total_items: int = 0
        self.chapters: int = 0
        self.trade_agreements: int = 0
        
    async def load(self):
        """Load all knowledge base files"""
        logger.info("Loading knowledge base", path=str(self.knowledge_path))
        
        try:
            # Load tariff codes
            await self._load_tariff_codes()
            
            # Load discount codes
            await self._load_discount_codes()
            
            # Load trade agreements
            await self._load_trade_agreements()
            
            # Load procedures
            await self._load_procedures()
            
            # Load terminology
            await self._load_terminology()
            
            self.last_updated = datetime.now()
            logger.info(
                "Knowledge base loaded",
                total_items=self.total_items,
                chapters=self.chapters,
            )
            
        except Exception as e:
            logger.error("Failed to load knowledge base", error=str(e))
            # Initialize with empty data
            self._initialize_empty()
    
    async def _load_tariff_codes(self):
        """Load tariff codes from JSON"""
        file_path = self.knowledge_path / "tariff_codes.json"
        
        if file_path.exists():
            with open(file_path, 'r', encoding='utf-8') as f:
                self.data['tariff'] = json.load(f)
                self.total_items = len(self.data['tariff'].get('items', []))
                self.chapters = len(self.data['tariff'].get('chapters', []))
        else:
            logger.warning("Tariff codes file not found, using defaults")
            self.data['tariff'] = self._get_default_tariff()
    
    async def _load_discount_codes(self):
        """Load discount/preference codes"""
        file_path = self.knowledge_path / "discount_codes.json"
        
        if file_path.exists():
            with open(file_path, 'r', encoding='utf-8') as f:
                self.data['discount_codes'] = json.load(f)
        else:
            self.data['discount_codes'] = self._get_default_discount_codes()
    
    async def _load_trade_agreements(self):
        """Load trade agreements"""
        file_path = self.knowledge_path / "trade_agreements.json"
        
        if file_path.exists():
            with open(file_path, 'r', encoding='utf-8') as f:
                self.data['agreements'] = json.load(f)
                self.trade_agreements = len(self.data['agreements'])
        else:
            self.data['agreements'] = self._get_default_agreements()
            self.trade_agreements = len(self.data['agreements'])
    
    async def _load_procedures(self):
        """Load TASHAR procedures"""
        file_path = self.knowledge_path / "tashar_procedure.json"
        
        if file_path.exists():
            with open(file_path, 'r', encoding='utf-8') as f:
                self.data['procedures'] = json.load(f)
        else:
            self.data['procedures'] = {}
    
    async def _load_terminology(self):
        """Load Hebrew terminology"""
        file_path = self.knowledge_path / "hebrew_terminology.json"
        
        if file_path.exists():
            with open(file_path, 'r', encoding='utf-8') as f:
                self.data['terminology'] = json.load(f)
        else:
            self.data['terminology'] = self._get_default_terminology()
    
    def _initialize_empty(self):
        """Initialize with empty/default data"""
        self.data = {
            'tariff': self._get_default_tariff(),
            'discount_codes': self._get_default_discount_codes(),
            'agreements': self._get_default_agreements(),
            'procedures': {},
            'terminology': self._get_default_terminology(),
        }
        self.total_items = 0
        self.chapters = 97
        self.trade_agreements = 16
    
    async def get_item(self, hs_code: str) -> Optional[Dict[str, Any]]:
        """Get information for a specific HS code"""
        items = self.data.get('tariff', {}).get('items', {})
        
        # Try exact match
        if hs_code in items:
            return items[hs_code]
        
        # Try without Israeli suffix (remove /X)
        base_code = hs_code.split('/')[0]
        if base_code in items:
            return items[base_code]
        
        # Try shorter codes
        for length in [8, 6, 4]:
            short_code = hs_code[:length]
            if short_code in items:
                return items[short_code]
        
        return None
    
    async def search(self, query: str, limit: int = 10) -> List[Dict[str, Any]]:
        """Search the knowledge base"""
        results = []
        query_lower = query.lower()
        
        items = self.data.get('tariff', {}).get('items', {})
        
        for code, item in items.items():
            score = 0
            
            # Check code match
            if query in code:
                score += 100
            
            # Check description match
            desc_he = item.get('description_he', '').lower()
            desc_en = item.get('description_en', '').lower()
            
            if query_lower in desc_he:
                score += 50
            if query_lower in desc_en:
                score += 50
            
            if score > 0:
                results.append({
                    'hs_code': code,
                    'description': item.get('description_he', item.get('description_en', '')),
                    'score': score,
                    'item': item,
                })
        
        # Sort by score and limit
        results.sort(key=lambda x: x['score'], reverse=True)
        return results[:limit]
    
    def get_discount_code(self, code: str) -> Optional[Dict[str, Any]]:
        """Get information about a discount code"""
        return self.data.get('discount_codes', {}).get(code)
    
    def get_agreement(self, country_code: str) -> Optional[Dict[str, Any]]:
        """Get trade agreement information"""
        agreements = self.data.get('agreements', [])
        for agreement in agreements:
            if agreement.get('code') == country_code:
                return agreement
        return None
    
    def get_terminology(self, term: str) -> Optional[Dict[str, Any]]:
        """Get terminology translation/explanation"""
        return self.data.get('terminology', {}).get(term)
    
    # ============================================
    # DEFAULT DATA
    # ============================================
    
    def _get_default_tariff(self) -> Dict[str, Any]:
        """Default tariff structure"""
        return {
            "version": "2025",
            "chapters": list(range(1, 98)),
            "items": {
                # Sample items - to be replaced with full tariff
                "8704.60.80.00": {
                    "description_he": "רכב חשמלי למשא",
                    "description_en": "Electric goods vehicles",
                    "duty_rate": 0,
                    "purchase_tax": 0,
                    "vat": 17,
                },
                "0804.40.10.00": {
                    "description_he": "אבוקדו טרי",
                    "description_en": "Fresh avocados",
                    "duty_rate": 7,
                    "purchase_tax": 0,
                    "vat": 17,
                },
            }
        }
    
    def _get_default_discount_codes(self) -> Dict[str, Any]:
        """Default discount codes"""
        return {
            "2": {
                "name": "Israel-USA FTA",
                "name_he": "הסכם סחר חופשי ישראל-ארה\"ב",
                "countries": ["US", "USA"],
                "year": 1985,
            },
            "92": {
                "name": "Israel-EU Association Agreement", 
                "name_he": "הסכם שיתוף עם האיחוד האירופי",
                "countries": ["EU", "DE", "FR", "IT", "ES", "NL", "BE", "AT", "PL"],
                "year": 1995,
            },
            # More codes to be added from official source
        }
    
    def _get_default_agreements(self) -> List[Dict[str, Any]]:
        """Default trade agreements list"""
        return [
            {"code": "2", "name": "Israel-USA FTA", "year": 1985},
            {"code": "92", "name": "Israel-EU Association", "year": 1995},
            {"code": "EFTA", "name": "Israel-EFTA", "year": 1992},
            {"code": "MX", "name": "Israel-Mexico FTA", "year": 2000},
            {"code": "CA", "name": "Israel-Canada FTA", "year": 1997},
            {"code": "TR", "name": "Israel-Turkey FTA", "year": 1997},
            {"code": "KR", "name": "Israel-South Korea FTA", "year": 2021},
            {"code": "AE", "name": "Israel-UAE FTA", "year": 2022},
            {"code": "CO", "name": "Israel-Colombia FTA", "year": 2020},
            {"code": "PA", "name": "Israel-Panama FTA", "year": 2020},
            {"code": "UA", "name": "Israel-Ukraine FTA", "year": 2021},
            {"code": "GT", "name": "Israel-Guatemala FTA", "year": 2023},
            {"code": "VN", "name": "Israel-Vietnam FTA", "year": 2024},
            {"code": "JO", "name": "Israel-Jordan FTA", "year": 1995},
            {"code": "EG", "name": "Israel-Egypt QIZ", "year": 2005},
            {"code": "MERCOSUR", "name": "Israel-Mercosur", "year": 2007},
        ]
    
    def _get_default_terminology(self) -> Dict[str, Any]:
        """Default Hebrew terminology"""
        return {
            "הצהרת יבוא": {"en": "Import Declaration", "definition": "מסמך הצהרה על טובין מיובאים"},
            "הצהרת יצוא": {"en": "Export Declaration", "definition": "מסמך הצהרה על טובין מיוצאים"},
            "פרט מכס": {"en": "Tariff Item", "definition": "קוד סיווג של 10 ספרות"},
            "תהליך השחרור": {"en": "Release Process (TASHAR)", "definition": "תהליך שחרור טובין מהמכס"},
            "ערך המכס": {"en": "Customs Value", "definition": "ערך לצרכי חישוב מכס"},
            "תעודת מקור": {"en": "Certificate of Origin", "definition": "אישור ארץ ייצור"},
            # More terms to be added
        }
