"""
RPA-PORT Israeli Customs AI
Claude Service - Anthropic API Integration
"""

import anthropic
from typing import Optional, List, Dict, Any, AsyncGenerator
import structlog
import json

from app.config import settings, SYSTEM_PROMPT

logger = structlog.get_logger()


class ClaudeService:
    """Service for interacting with Anthropic's Claude API"""
    
    def __init__(self):
        self.client = anthropic.Anthropic(api_key=settings.ANTHROPIC_API_KEY)
        self.model = settings.CLAUDE_MODEL
        self.max_tokens = settings.CLAUDE_MAX_TOKENS
        
    async def chat(
        self,
        message: str,
        conversation_history: Optional[List[Dict[str, str]]] = None,
        tenant_id: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None,
    ) -> str:
        """
        Send a message to Claude and get a response
        
        Args:
            message: User's message
            conversation_history: Previous messages in the conversation
            tenant_id: Tenant identifier for multi-tenant mode
            context: Additional context (uploaded files, etc.)
        
        Returns:
            Claude's response text
        """
        try:
            # Build messages array
            messages = []
            
            # Add conversation history if provided
            if conversation_history:
                messages.extend(conversation_history)
            
            # Add current message
            messages.append({
                "role": "user",
                "content": message
            })
            
            # Build system prompt with context
            system = self._build_system_prompt(tenant_id, context)
            
            # Call Claude API
            response = self.client.messages.create(
                model=self.model,
                max_tokens=self.max_tokens,
                system=system,
                messages=messages,
            )
            
            # Extract response text
            response_text = response.content[0].text
            
            logger.info(
                "Claude response generated",
                tenant_id=tenant_id,
                input_tokens=response.usage.input_tokens,
                output_tokens=response.usage.output_tokens,
            )
            
            return response_text
            
        except anthropic.APIError as e:
            logger.error("Claude API error", error=str(e))
            raise
        except Exception as e:
            logger.error("Unexpected error in Claude service", error=str(e))
            raise
    
    async def stream_chat(
        self,
        message: str,
        conversation_history: Optional[List[Dict[str, str]]] = None,
        tenant_id: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None,
    ) -> AsyncGenerator[str, None]:
        """
        Stream a response from Claude
        
        Yields response text chunks as they arrive
        """
        try:
            messages = []
            
            if conversation_history:
                messages.extend(conversation_history)
            
            messages.append({
                "role": "user",
                "content": message
            })
            
            system = self._build_system_prompt(tenant_id, context)
            
            # Stream response
            with self.client.messages.stream(
                model=self.model,
                max_tokens=self.max_tokens,
                system=system,
                messages=messages,
            ) as stream:
                for text in stream.text_stream:
                    yield text
                    
        except Exception as e:
            logger.error("Error in streaming response", error=str(e))
            raise
    
    async def classify_product(
        self,
        description: str,
        additional_info: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Classify a product and return HS code with explanation
        
        Args:
            description: Product description
            additional_info: Additional information (material, use, etc.)
        
        Returns:
            Classification result with HS code, confidence, and explanation
        """
        prompt = f"""סווג את המוצר הבא לפי תעריף המכס הישראלי:

**תיאור המוצר:** {description}

{"**מידע נוסף:** " + json.dumps(additional_info, ensure_ascii=False) if additional_info else ""}

אנא החזר תשובה בפורמט JSON הבא:
{{
    "hs_code": "קוד HS מלא (10 ספרות)",
    "description_he": "תיאור בעברית",
    "description_en": "English description",
    "chapter": "מספר פרק",
    "heading": "כותרת",
    "subheading": "כותרת משנה",
    "duty_rate": "שיעור מכס באחוזים",
    "purchase_tax": "מס קנייה באחוזים",
    "vat": "מע\"מ באחוזים",
    "confidence": "רמת ודאות (0-100)",
    "explanation": "הסבר מפורט לסיווג",
    "notes": ["הערות נוספות"],
    "requirements": ["דרישות (רישיונות, תקנים, וכו')"]
}}"""
        
        response = await self.chat(prompt)
        
        # Parse JSON response
        try:
            # Extract JSON from response
            json_start = response.find('{')
            json_end = response.rfind('}') + 1
            json_str = response[json_start:json_end]
            result = json.loads(json_str)
            return result
        except json.JSONDecodeError:
            logger.warning("Failed to parse classification JSON", response=response)
            return {
                "hs_code": "unknown",
                "explanation": response,
                "confidence": 0,
            }
    
    async def analyze_declaration(
        self,
        declaration_data: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Analyze an import/export declaration
        
        Args:
            declaration_data: Parsed declaration data
        
        Returns:
            Analysis results with verification, issues, and recommendations
        """
        prompt = f"""נתח את הצהרת היבוא/יצוא הבאה:

{json.dumps(declaration_data, ensure_ascii=False, indent=2)}

בדוק:
1. התאמת פרט המכס לתיאור הטובין
2. נכונות חישוב המיסים
3. שלמות המסמכים
4. התאמה לנוהל תש"ר
5. בעיות פוטנציאליות

החזר תשובה בפורמט JSON:
{{
    "status": "תקין/בעיות/דורש בדיקה",
    "classification_check": {{
        "correct": true/false,
        "suggested_code": "קוד מוצע אם שונה",
        "reason": "סיבה"
    }},
    "tax_calculation": {{
        "correct": true/false,
        "expected": {{"duty": 0, "vat": 0, "purchase_tax": 0}},
        "difference": 0
    }},
    "documents": {{
        "complete": true/false,
        "missing": ["מסמכים חסרים"]
    }},
    "issues": ["בעיות שנמצאו"],
    "recommendations": ["המלצות"]
}}"""
        
        response = await self.chat(prompt)
        
        try:
            json_start = response.find('{')
            json_end = response.rfind('}') + 1
            json_str = response[json_start:json_end]
            return json.loads(json_str)
        except json.JSONDecodeError:
            return {
                "status": "error",
                "raw_response": response,
            }
    
    def _build_system_prompt(
        self,
        tenant_id: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None,
    ) -> str:
        """Build the system prompt with tenant and context information"""
        
        prompt_parts = [SYSTEM_PROMPT]
        
        if tenant_id:
            prompt_parts.append(f"\n\n🏢 **לקוח:** {tenant_id}")
        
        if context:
            if "knowledge_base" in context:
                prompt_parts.append(f"\n\n📚 **מאגר ידע זמין:**\n{context['knowledge_base']}")
            
            if "uploaded_files" in context:
                prompt_parts.append(f"\n\n📎 **קבצים שהועלו:**\n{context['uploaded_files']}")
        
        return "\n".join(prompt_parts)
