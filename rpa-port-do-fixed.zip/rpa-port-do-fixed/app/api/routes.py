"""
RPA-PORT Israeli Customs AI
API Routes
"""

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from fastapi.responses import StreamingResponse
from typing import Optional, List
import json
import structlog

from app.models.schemas import (
    ChatRequest,
    ChatResponse,
    ClassifyRequest,
    ClassifyResponse,
    DeclarationAnalysisRequest,
    DeclarationAnalysisResponse,
    KnowledgeBaseStatus,
)
from app.services.claude_service import ClaudeService

logger = structlog.get_logger()
router = APIRouter()


# Dependency to get Claude service
async def get_claude_service():
    from app.main import app
    return app.state.claude


# ============================================
# CHAT ENDPOINTS
# ============================================

@router.post("/chat", response_model=ChatResponse)
async def chat(
    request: ChatRequest,
    claude: ClaudeService = Depends(get_claude_service),
):
    """
    Send a message and get a response
    
    Supports Hebrew and English
    """
    try:
        response = await claude.chat(
            message=request.message,
            conversation_history=request.history,
            tenant_id=request.tenant_id,
            context=request.context,
        )
        
        return ChatResponse(
            message=response,
            tenant_id=request.tenant_id,
        )
        
    except Exception as e:
        logger.error("Chat error", error=str(e))
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/chat/stream")
async def chat_stream(
    request: ChatRequest,
    claude: ClaudeService = Depends(get_claude_service),
):
    """
    Stream a chat response
    
    Returns Server-Sent Events (SSE)
    """
    async def generate():
        try:
            async for chunk in claude.stream_chat(
                message=request.message,
                conversation_history=request.history,
                tenant_id=request.tenant_id,
                context=request.context,
            ):
                yield f"data: {json.dumps({'text': chunk})}\n\n"
            yield "data: [DONE]\n\n"
        except Exception as e:
            yield f"data: {json.dumps({'error': str(e)})}\n\n"
    
    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
    )


# ============================================
# CLASSIFICATION ENDPOINTS
# ============================================

@router.post("/classify", response_model=ClassifyResponse)
async def classify_product(
    request: ClassifyRequest,
    claude: ClaudeService = Depends(get_claude_service),
):
    """
    Classify a product and get HS code
    
    Returns:
    - HS Code (10 digits)
    - Duty rates
    - Requirements
    - Confidence score
    """
    try:
        result = await claude.classify_product(
            description=request.description,
            additional_info=request.additional_info,
        )
        
        return ClassifyResponse(**result)
        
    except Exception as e:
        logger.error("Classification error", error=str(e))
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/classify/batch")
async def classify_batch(
    products: List[ClassifyRequest],
    claude: ClaudeService = Depends(get_claude_service),
):
    """
    Classify multiple products
    
    Useful for bulk classification
    """
    results = []
    for product in products:
        try:
            result = await claude.classify_product(
                description=product.description,
                additional_info=product.additional_info,
            )
            results.append({"success": True, **result})
        except Exception as e:
            results.append({
                "success": False,
                "error": str(e),
                "description": product.description,
            })
    
    return {"results": results}


# ============================================
# DECLARATION ANALYSIS ENDPOINTS
# ============================================

@router.post("/declaration/analyze", response_model=DeclarationAnalysisResponse)
async def analyze_declaration(
    request: DeclarationAnalysisRequest,
    claude: ClaudeService = Depends(get_claude_service),
):
    """
    Analyze an import/export declaration
    
    Checks:
    - Classification accuracy
    - Tax calculations
    - Document completeness
    - TASHAR compliance
    """
    try:
        result = await claude.analyze_declaration(
            declaration_data=request.declaration_data,
        )
        
        return DeclarationAnalysisResponse(**result)
        
    except Exception as e:
        logger.error("Declaration analysis error", error=str(e))
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/declaration/upload")
async def upload_declaration(
    file: UploadFile = File(...),
    tenant_id: Optional[str] = Form(None),
    claude: ClaudeService = Depends(get_claude_service),
):
    """
    Upload and analyze a declaration document
    
    Supports: PDF, images
    """
    # Read file content
    content = await file.read()
    
    # TODO: Parse PDF/image using appropriate library
    # For now, return placeholder
    
    return {
        "filename": file.filename,
        "size": len(content),
        "status": "uploaded",
        "message": "File parsing coming soon",
    }


# ============================================
# KNOWLEDGE BASE ENDPOINTS
# ============================================

@router.get("/knowledge/status", response_model=KnowledgeBaseStatus)
async def knowledge_base_status():
    """
    Get knowledge base status
    
    Shows last update time and available data
    """
    from app.main import app
    tariff_db = app.state.tariff_db
    
    return KnowledgeBaseStatus(
        last_updated=tariff_db.last_updated,
        total_items=tariff_db.total_items,
        chapters=tariff_db.chapters,
        trade_agreements=tariff_db.trade_agreements,
        status="loaded",
    )


@router.post("/knowledge/search")
async def search_knowledge_base(
    query: str,
    limit: int = 10,
):
    """
    Search the knowledge base
    
    Searches tariff codes, descriptions, and procedures
    """
    from app.main import app
    tariff_db = app.state.tariff_db
    
    results = await tariff_db.search(query, limit)
    return {"results": results}


@router.get("/knowledge/tariff/{hs_code}")
async def get_tariff_info(hs_code: str):
    """
    Get information for a specific HS code
    """
    from app.main import app
    tariff_db = app.state.tariff_db
    
    info = await tariff_db.get_item(hs_code)
    if not info:
        raise HTTPException(status_code=404, detail="HS code not found")
    
    return info


# ============================================
# TRADE AGREEMENTS ENDPOINTS
# ============================================

@router.get("/agreements")
async def list_trade_agreements():
    """
    List all trade agreements
    """
    agreements = [
        {"code": "2", "name": "Israel-USA FTA", "year": 1985},
        {"code": "92", "name": "Israel-EU Association", "year": 1995},
        {"code": "EFTA", "name": "Israel-EFTA", "year": 1992},
        {"code": "MX", "name": "Israel-Mexico FTA", "year": 2000},
        {"code": "CA", "name": "Israel-Canada FTA", "year": 1997},
        {"code": "TR", "name": "Israel-Turkey FTA", "year": 1997},
        {"code": "KR", "name": "Israel-South Korea FTA", "year": 2021},
        {"code": "AE", "name": "Israel-UAE FTA", "year": 2022},
        {"code": "CO", "name": "Israel-Colombia FTA", "year": 2020},
        {"code": "PA", "name": "Israel-Panama FTA", "year": 2020},
        {"code": "UA", "name": "Israel-Ukraine FTA", "year": 2021},
        {"code": "GT", "name": "Israel-Guatemala FTA", "year": 2023},
        {"code": "VN", "name": "Israel-Vietnam FTA", "year": 2024},
        {"code": "JO", "name": "Israel-Jordan FTA", "year": 1995},
        {"code": "EG", "name": "Israel-Egypt QIZ", "year": 2005},
        {"code": "MERCOSUR", "name": "Israel-Mercosur", "year": 2007},
    ]
    return {"agreements": agreements}


@router.get("/agreements/{country_code}")
async def get_agreement_details(country_code: str):
    """
    Get details for a specific trade agreement
    """
    # TODO: Implement full agreement details
    return {
        "code": country_code,
        "message": "Full agreement details coming soon",
    }
