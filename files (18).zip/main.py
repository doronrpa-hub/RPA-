from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, List, Dict
import anthropic
import os

app = FastAPI(title="RPA-PORT Customs AI", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

SYSTEM_PROMPT = """אתה מומחה בכיר למכס ישראלי של חברת RPA-PORT LTD.

יכולות:
- סיווג טובין לפי HS Code (10 ספרות)
- ניתוח הצהרות יבוא ויצוא
- חישוב מיסים (מכס, מע"מ, מס קנייה)
- זיהוי הטבות מהסכמי סחר

אתר: www.rpa-port.com
מייל: devrpa@rpa-port.co.il"""

class ChatRequest(BaseModel):
    message: str
    history: Optional[List[Dict[str, str]]] = None

@app.get("/")
async def root():
    return {
        "name": "RPA-PORT Customs AI",
        "version": "1.0.0",
        "website": "www.rpa-port.com",
        "status": "running",
        "endpoints": {
            "health": "/health",
            "chat": "/api/chat",
            "docs": "/docs"
        }
    }

@app.get("/health")
async def health():
    return {"status": "healthy", "service": "rpa-port-customs-ai"}

@app.post("/api/chat")
async def chat(request: ChatRequest):
    try:
        api_key = os.getenv("ANTHROPIC_API_KEY")
        if not api_key:
            raise HTTPException(status_code=500, detail="API key not configured")
        
        client = anthropic.Anthropic(api_key=api_key)
        messages = request.history or []
        messages.append({"role": "user", "content": request.message})
        
        response = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=4096,
            system=SYSTEM_PROMPT,
            messages=messages,
        )
        return {"response": response.content[0].text}
    except anthropic.APIError as e:
        raise HTTPException(status_code=500, detail=f"Claude API error: {str(e)}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/classify")
async def classify(description: str):
    try:
        api_key = os.getenv("ANTHROPIC_API_KEY")
        if not api_key:
            raise HTTPException(status_code=500, detail="API key not configured")
        
        client = anthropic.Anthropic(api_key=api_key)
        
        prompt = f"סווג את המוצר הבא לפי תעריף המכס הישראלי: {description}"
        
        response = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=2048,
            system=SYSTEM_PROMPT,
            messages=[{"role": "user", "content": prompt}],
        )
        return {"classification": response.content[0].text}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
