# 🚀 RPA-PORT LTD - Israeli Customs AI Platform

## DigitalOcean Deployment Guide

### Overview
AI-powered Israeli Customs Classification and Declaration System built on Anthropic's Claude API.

---

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    DigitalOcean                         │
├─────────────────────────────────────────────────────────┤
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐ │
│  │   Droplet   │    │  Spaces     │    │  Database   │ │
│  │  (App)      │◄──►│  (Storage)  │◄──►│  (Postgres) │ │
│  └──────┬──────┘    └─────────────┘    └─────────────┘ │
│         │                                               │
│         ▼                                               │
│  ┌─────────────┐                                        │
│  │ Claude API  │                                        │
│  │ (Anthropic) │                                        │
│  └─────────────┘                                        │
└─────────────────────────────────────────────────────────┘
```

---

## 📁 Project Structure

```
rpa-port-digitalocean/
├── README.md
├── docker-compose.yml
├── Dockerfile
├── .env.example
├── app/
│   ├── main.py              # FastAPI application
│   ├── config.py            # Configuration
│   ├── api/
│   │   ├── __init__.py
│   │   ├── routes.py        # API endpoints
│   │   └── websocket.py     # Real-time chat
│   ├── services/
│   │   ├── __init__.py
│   │   ├── claude_service.py    # Anthropic Claude integration
│   │   ├── customs_service.py   # Customs logic
│   │   └── storage_service.py   # DigitalOcean Spaces
│   ├── knowledge/
│   │   ├── __init__.py
│   │   ├── tariff_db.py     # Customs tariff database
│   │   ├── procedures.py    # TASHAR procedures
│   │   └── terminology.py   # Hebrew terminology
│   └── models/
│       ├── __init__.py
│       └── schemas.py       # Pydantic models
├── knowledge_base/
│   ├── customs_ordinance.json
│   ├── tashar_procedure.json
│   ├── tariff_codes.json
│   ├── discount_codes.json
│   ├── trade_agreements.json
│   └── hebrew_terminology.json
├── scripts/
│   ├── setup.sh
│   ├── deploy.sh
│   └── backup.sh
└── terraform/
    ├── main.tf
    ├── variables.tf
    └── outputs.tf
```

---

## 🚀 Quick Start

### 1. Clone Repository
```bash
git clone https://github.com/rpa-port/customs-ai.git
cd customs-ai
```

### 2. Configure Environment
```bash
cp .env.example .env
# Edit .env with your credentials
```

### 3. Deploy to DigitalOcean
```bash
./scripts/deploy.sh
```

---

## 🔑 Required API Keys

| Service | Variable | Get From |
|---------|----------|----------|
| Anthropic Claude | `ANTHROPIC_API_KEY` | https://console.anthropic.com |
| DigitalOcean | `DO_TOKEN` | https://cloud.digitalocean.com/account/api/tokens |
| DigitalOcean Spaces | `DO_SPACES_KEY` | https://cloud.digitalocean.com/spaces |

---

## 💰 Estimated Costs (Monthly)

| Resource | Spec | Cost |
|----------|------|------|
| Droplet | 2GB RAM, 1 vCPU | $12 |
| Spaces | 250GB Storage | $5 |
| Database | Basic PostgreSQL | $15 |
| Claude API | ~100K tokens/day | ~$50 |
| **Total** | | **~$82/month** |

---

## 📞 Support

- Email: devrpa@rpa-port.co.il
- Website: https://www.rpa-port.com
