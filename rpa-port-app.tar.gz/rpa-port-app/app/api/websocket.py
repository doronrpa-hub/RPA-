"""
RPA-PORT Israeli Customs AI
WebSocket Handler for Real-time Chat
"""

from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from typing import Dict, List
import json
import structlog
import asyncio

logger = structlog.get_logger()
router = APIRouter()


class ConnectionManager:
    """Manage WebSocket connections"""
    
    def __init__(self):
        # Active connections: {tenant_id: [websockets]}
        self.active_connections: Dict[str, List[WebSocket]] = {}
        # Conversation history: {connection_id: messages}
        self.conversations: Dict[str, List[Dict]] = {}
    
    async def connect(self, websocket: WebSocket, tenant_id: str = "default"):
        """Accept a new WebSocket connection"""
        await websocket.accept()
        
        if tenant_id not in self.active_connections:
            self.active_connections[tenant_id] = []
        
        self.active_connections[tenant_id].append(websocket)
        self.conversations[id(websocket)] = []
        
        logger.info("WebSocket connected", tenant_id=tenant_id)
    
    def disconnect(self, websocket: WebSocket, tenant_id: str = "default"):
        """Remove a WebSocket connection"""
        if tenant_id in self.active_connections:
            if websocket in self.active_connections[tenant_id]:
                self.active_connections[tenant_id].remove(websocket)
        
        # Clean up conversation history
        if id(websocket) in self.conversations:
            del self.conversations[id(websocket)]
        
        logger.info("WebSocket disconnected", tenant_id=tenant_id)
    
    async def send_message(self, websocket: WebSocket, message: dict):
        """Send a message to a specific connection"""
        await websocket.send_json(message)
    
    async def broadcast(self, tenant_id: str, message: dict):
        """Broadcast message to all connections in a tenant"""
        if tenant_id in self.active_connections:
            for connection in self.active_connections[tenant_id]:
                await connection.send_json(message)
    
    def get_history(self, websocket: WebSocket) -> List[Dict]:
        """Get conversation history for a connection"""
        return self.conversations.get(id(websocket), [])
    
    def add_to_history(self, websocket: WebSocket, role: str, content: str):
        """Add a message to conversation history"""
        if id(websocket) in self.conversations:
            self.conversations[id(websocket)].append({
                "role": role,
                "content": content,
            })


# Global connection manager
manager = ConnectionManager()


@router.websocket("/chat")
async def websocket_chat(websocket: WebSocket, tenant_id: str = "default"):
    """
    WebSocket endpoint for real-time chat
    
    Message format (client -> server):
    {
        "type": "message",
        "content": "User's message",
        "context": {} // Optional additional context
    }
    
    Response format (server -> client):
    {
        "type": "response" | "stream" | "error",
        "content": "Response text",
        "done": true/false // For streaming
    }
    """
    await manager.connect(websocket, tenant_id)
    
    try:
        # Send welcome message
        await manager.send_message(websocket, {
            "type": "system",
            "content": "שלום! אני מערכת ה-AI של RPA-PORT לסיווג מכס. איך אוכל לעזור?",
        })
        
        while True:
            # Receive message
            data = await websocket.receive_json()
            
            if data.get("type") == "message":
                user_message = data.get("content", "")
                context = data.get("context", {})
                
                # Add to history
                manager.add_to_history(websocket, "user", user_message)
                
                # Get Claude service
                from app.main import app
                claude = app.state.claude
                
                # Stream response
                await manager.send_message(websocket, {
                    "type": "stream_start",
                })
                
                full_response = ""
                try:
                    async for chunk in claude.stream_chat(
                        message=user_message,
                        conversation_history=manager.get_history(websocket)[:-1],  # Exclude current
                        tenant_id=tenant_id,
                        context=context,
                    ):
                        full_response += chunk
                        await manager.send_message(websocket, {
                            "type": "stream",
                            "content": chunk,
                            "done": False,
                        })
                    
                    # Stream complete
                    await manager.send_message(websocket, {
                        "type": "stream",
                        "content": "",
                        "done": True,
                    })
                    
                    # Add assistant response to history
                    manager.add_to_history(websocket, "assistant", full_response)
                    
                except Exception as e:
                    logger.error("Error in chat stream", error=str(e))
                    await manager.send_message(websocket, {
                        "type": "error",
                        "content": f"שגיאה: {str(e)}",
                    })
            
            elif data.get("type") == "ping":
                await manager.send_message(websocket, {
                    "type": "pong",
                })
            
            elif data.get("type") == "clear_history":
                manager.conversations[id(websocket)] = []
                await manager.send_message(websocket, {
                    "type": "system",
                    "content": "היסטוריית השיחה נמחקה",
                })
                
    except WebSocketDisconnect:
        manager.disconnect(websocket, tenant_id)
    except Exception as e:
        logger.error("WebSocket error", error=str(e))
        manager.disconnect(websocket, tenant_id)


@router.websocket("/chat/{tenant_id}")
async def websocket_chat_tenant(websocket: WebSocket, tenant_id: str):
    """WebSocket endpoint with explicit tenant ID"""
    await websocket_chat(websocket, tenant_id)
