"""
RPA-PORT Israeli Customs AI
Main FastAPI Application
"""

from contextlib import asynccontextmanager
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import structlog
import time

from app.config import settings
from app.api.routes import router as api_router
from app.api.websocket import router as ws_router
from app.services.claude_service import ClaudeService
from app.knowledge.tariff_db import TariffDatabase

# Configure structured logging
structlog.configure(
    processors=[
        structlog.stdlib.filter_by_level,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.add_log_level,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.JSONRenderer()
    ],
    wrapper_class=structlog.stdlib.BoundLogger,
    context_class=dict,
    logger_factory=structlog.stdlib.LoggerFactory(),
)

logger = structlog.get_logger()


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan handler"""
    # Startup
    logger.info("Starting RPA-PORT Customs AI", environment=settings.ENVIRONMENT)
    
    # Initialize services
    app.state.claude = ClaudeService()
    app.state.tariff_db = TariffDatabase()
    
    # Load knowledge base
    await app.state.tariff_db.load()
    logger.info("Knowledge base loaded successfully")
    
    yield
    
    # Shutdown
    logger.info("Shutting down RPA-PORT Customs AI")


# Create FastAPI application
app = FastAPI(
    title="RPA-PORT Israeli Customs AI",
    description="""
    🇮🇱 AI-powered Israeli Customs Classification and Declaration System
    
    ## Features
    - HS Code Classification
    - Customs Declaration Analysis
    - Trade Agreement Benefits
    - Hebrew/English Support
    - Real-time Chat Interface
    
    ## Powered by
    - Anthropic Claude AI
    - Israeli Customs Knowledge Base
    - TASHAR Procedures
    """,
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan,
)

# CORS Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Request timing middleware
@app.middleware("http")
async def add_process_time_header(request: Request, call_next):
    start_time = time.time()
    response = await call_next(request)
    process_time = time.time() - start_time
    response.headers["X-Process-Time"] = str(process_time)
    return response


# Include routers
app.include_router(api_router, prefix="/api/v1", tags=["API"])
app.include_router(ws_router, prefix="/ws", tags=["WebSocket"])


# Health check endpoint
@app.get("/health", tags=["Health"])
async def health_check():
    """Health check endpoint for load balancers"""
    return {
        "status": "healthy",
        "service": "rpa-port-customs-ai",
        "version": "1.0.0",
        "environment": settings.ENVIRONMENT,
    }


# Root endpoint
@app.get("/", tags=["Root"])
async def root():
    """Root endpoint with API information"""
    return {
        "name": "RPA-PORT Israeli Customs AI",
        "version": "1.0.0",
        "description": "AI-powered Israeli Customs Classification System",
        "docs": "/docs",
        "health": "/health",
        "api": "/api/v1",
        "websocket": "/ws/chat",
    }


# Global exception handler
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.error(
        "Unhandled exception",
        error=str(exc),
        path=request.url.path,
        method=request.method,
    )
    return JSONResponse(
        status_code=500,
        content={
            "error": "Internal server error",
            "message": "An unexpected error occurred",
        },
    )


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        reload=settings.DEBUG,
    )
