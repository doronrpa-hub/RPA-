"""
RPA-PORT Israeli Customs AI
Configuration Settings
"""

from pydantic_settings import BaseSettings
from typing import List
import json


class Settings(BaseSettings):
    """Application settings loaded from environment variables"""
    
    # Application
    ENVIRONMENT: str = "development"
    SECRET_KEY: str = "change-me-in-production"
    DEBUG: bool = False
    LOG_LEVEL: str = "INFO"
    
    # Anthropic Claude API
    ANTHROPIC_API_KEY: str = ""
    CLAUDE_MODEL: str = "claude-sonnet-4-20250514"
    CLAUDE_MAX_TOKENS: int = 4096
    
    # Database
    DATABASE_URL: str = "postgresql://localhost/customs_ai"
    
    # Redis
    REDIS_URL: str = "redis://localhost:6379/0"
    
    # DigitalOcean Spaces
    DO_SPACES_KEY: str = ""
    DO_SPACES_SECRET: str = ""
    DO_SPACES_BUCKET: str = "rpa-port-customs"
    DO_SPACES_REGION: str = "fra1"
    DO_SPACES_ENDPOINT: str = ""
    
    # Multi-tenant
    MULTI_TENANT_ENABLED: bool = True
    DEFAULT_TENANT_ID: str = "default"
    
    # Knowledge Base
    KNOWLEDGE_AUTO_UPDATE: bool = True
    KNOWLEDGE_UPDATE_DAY: str = "sunday"
    KNOWLEDGE_UPDATE_HOUR: int = 3
    
    # Rate Limiting
    RATE_LIMIT_PER_MINUTE: int = 60
    RATE_LIMIT_PER_HOUR: int = 1000
    
    # CORS
    CORS_ORIGINS: List[str] = ["http://localhost:3000"]
    
    # Monitoring
    SENTRY_DSN: str = ""
    
    class Config:
        env_file = ".env"
        case_sensitive = True
        
        @classmethod
        def parse_env_var(cls, field_name: str, raw_val: str):
            if field_name == "CORS_ORIGINS":
                return json.loads(raw_val)
            return raw_val


# Global settings instance
settings = Settings()


# System prompt for Claude - Israeli Customs Expert
SYSTEM_PROMPT = """אתה מומחה בכיר למכס ישראלי, עם ידע מעמיק ב:

📚 **מקורות ידע:**
- פקודת המכס (נוסח חדש)
- נוהל תש"ר 2024 (תהליך השחרור)
- צו תעריף המכס והפטורים ומס קנייה
- הסכמי סחר בינלאומיים (ארה"ב, האיחוד האירופי, EFTA, ועוד)
- דרישות משרדי ממשלה (בריאות, חקלאות, מכון התקנים)

🎯 **יכולות:**
- סיווג טובין לפי HS Code (10 ספרות)
- ניתוח הצהרות יבוא ויצוא
- חישוב מיסים (מכס, מע"מ, מס קנייה)
- זיהוי הטבות מהסכמי סחר
- בדיקת דרישות רישוי ותקינה

🗣️ **שפה:**
- מדבר עברית מקצועית (מונחים רשמיים)
- יכול לענות גם באנגלית
- משתמש במונחים מתעריף המכס הישראלי

📋 **כללים:**
1. תמיד לציין מקור המידע (סעיף חוק, נוהל)
2. להזהיר כשיש אי-ודאות
3. להפנות לייעוץ מקצועי בנושאים מורכבים
4. לעדכן כשהמידע עשוי להיות לא עדכני

אני כאן לעזור לך בכל שאלה הקשורה ליבוא, יצוא, סיווג ומכס בישראל!"""
