"""
RPA-PORT Israeli Customs AI
Pydantic Models and Schemas
"""

from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from datetime import datetime


# ============================================
# CHAT MODELS
# ============================================

class ChatMessage(BaseModel):
    """A single chat message"""
    role: str = Field(..., description="Message role: user or assistant")
    content: str = Field(..., description="Message content")


class ChatRequest(BaseModel):
    """Chat request model"""
    message: str = Field(..., description="User's message")
    history: Optional[List[Dict[str, str]]] = Field(
        default=None, 
        description="Conversation history"
    )
    tenant_id: Optional[str] = Field(
        default=None, 
        description="Tenant identifier"
    )
    context: Optional[Dict[str, Any]] = Field(
        default=None, 
        description="Additional context"
    )
    
    class Config:
        json_schema_extra = {
            "example": {
                "message": "איך מסווגים טלפון נייד?",
                "tenant_id": "company-123",
            }
        }


class ChatResponse(BaseModel):
    """Chat response model"""
    message: str = Field(..., description="Assistant's response")
    tenant_id: Optional[str] = Field(default=None)
    tokens_used: Optional[int] = Field(default=None)


# ============================================
# CLASSIFICATION MODELS
# ============================================

class ClassifyRequest(BaseModel):
    """Product classification request"""
    description: str = Field(..., description="Product description")
    additional_info: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Additional info (material, use, origin, etc.)"
    )
    
    class Config:
        json_schema_extra = {
            "example": {
                "description": "אוזניות אלחוטיות בלוטוס עם מיקרופון",
                "additional_info": {
                    "material": "פלסטיק",
                    "origin": "סין",
                    "value_usd": 50
                }
            }
        }


class ClassifyResponse(BaseModel):
    """Product classification response"""
    hs_code: str = Field(..., description="HS Code (10 digits)")
    description_he: Optional[str] = Field(default=None, description="Hebrew description")
    description_en: Optional[str] = Field(default=None, description="English description")
    chapter: Optional[str] = Field(default=None, description="Chapter number")
    heading: Optional[str] = Field(default=None, description="Heading")
    subheading: Optional[str] = Field(default=None, description="Subheading")
    duty_rate: Optional[str] = Field(default=None, description="Duty rate %")
    purchase_tax: Optional[str] = Field(default=None, description="Purchase tax %")
    vat: Optional[str] = Field(default="17%", description="VAT %")
    confidence: Optional[int] = Field(default=None, description="Confidence 0-100")
    explanation: Optional[str] = Field(default=None, description="Classification explanation")
    notes: Optional[List[str]] = Field(default=None, description="Additional notes")
    requirements: Optional[List[str]] = Field(default=None, description="Requirements")
    
    class Config:
        json_schema_extra = {
            "example": {
                "hs_code": "8518.30.00.00/9",
                "description_he": "אוזניות",
                "description_en": "Headphones",
                "chapter": "85",
                "heading": "8518",
                "duty_rate": "0%",
                "purchase_tax": "0%",
                "vat": "17%",
                "confidence": 95,
                "explanation": "אוזניות מסווגות בפרק 85 - מכשירים חשמליים...",
            }
        }


# ============================================
# DECLARATION MODELS
# ============================================

class DeclarationItem(BaseModel):
    """A single item in a declaration"""
    item_number: int
    hs_code: str
    description: str
    quantity: float
    unit: str
    value: float
    currency: str
    origin_country: str
    duty_rate: Optional[float] = None
    purchase_tax: Optional[float] = None


class DeclarationAnalysisRequest(BaseModel):
    """Declaration analysis request"""
    declaration_data: Dict[str, Any] = Field(
        ..., 
        description="Parsed declaration data"
    )
    
    class Config:
        json_schema_extra = {
            "example": {
                "declaration_data": {
                    "declaration_number": "26014406015562",
                    "type": "import",
                    "importer": "Company Ltd",
                    "items": [
                        {
                            "hs_code": "8704.60.80.00/5",
                            "description": "GMC Sierra EV",
                            "value": 104000,
                            "currency": "USD"
                        }
                    ]
                }
            }
        }


class DeclarationAnalysisResponse(BaseModel):
    """Declaration analysis response"""
    status: str = Field(..., description="תקין/בעיות/דורש בדיקה")
    classification_check: Optional[Dict[str, Any]] = None
    tax_calculation: Optional[Dict[str, Any]] = None
    documents: Optional[Dict[str, Any]] = None
    issues: Optional[List[str]] = None
    recommendations: Optional[List[str]] = None
    raw_response: Optional[str] = None


# ============================================
# KNOWLEDGE BASE MODELS
# ============================================

class TariffItem(BaseModel):
    """A single tariff item"""
    hs_code: str
    description_he: str
    description_en: Optional[str] = None
    duty_rate: float
    purchase_tax: float = 0
    vat: float = 17
    unit: Optional[str] = None
    notes: Optional[List[str]] = None
    requirements: Optional[List[str]] = None
    preferential_rates: Optional[Dict[str, float]] = None


class KnowledgeBaseStatus(BaseModel):
    """Knowledge base status"""
    last_updated: Optional[datetime] = None
    total_items: int = 0
    chapters: int = 0
    trade_agreements: int = 0
    status: str = "unknown"


class SearchResult(BaseModel):
    """Knowledge base search result"""
    hs_code: str
    description: str
    score: float
    highlight: Optional[str] = None


# ============================================
# TENANT MODELS
# ============================================

class Tenant(BaseModel):
    """Tenant (customer) model"""
    id: str
    name: str
    vat_number: str
    email: Optional[str] = None
    created_at: datetime
    settings: Optional[Dict[str, Any]] = None


class TenantCreate(BaseModel):
    """Create tenant request"""
    name: str
    vat_number: str = Field(..., description="Israeli VAT number (9 digits)")
    email: Optional[str] = None


# ============================================
# TRADE AGREEMENT MODELS
# ============================================

class TradeAgreement(BaseModel):
    """Trade agreement model"""
    code: str
    name: str
    name_he: Optional[str] = None
    countries: List[str]
    year_signed: int
    in_force: bool = True
    preferential_rates: Optional[Dict[str, Any]] = None
    origin_requirements: Optional[str] = None
    certificate_type: Optional[str] = None


class DiscountCode(BaseModel):
    """Discount/preference code model"""
    code: str
    description: str
    description_he: Optional[str] = None
    agreement: Optional[str] = None
    conditions: Optional[List[str]] = None


# ============================================
# FILE UPLOAD MODELS
# ============================================

class FileUploadResponse(BaseModel):
    """File upload response"""
    filename: str
    size: int
    content_type: str
    status: str
    parsed_data: Optional[Dict[str, Any]] = None
    errors: Optional[List[str]] = None
